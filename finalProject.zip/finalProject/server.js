/*
Name: Philip Jochems and Michael Featherston
Class: CSC337
Assignment: Final Project
File: server.js
Purpose: This file creates a page that runs of the ip 127.0.0.1 at the port 80, using express. The server utilizes index.html,post.html,home.thml, functions.js and style.css,
to create a website called ostaa, where users can buy sell items to each other.


*/

//Initalizes mongodb and express
const express = require('express');
const mongoose = require('mongoose');
const parser = require('body-parser');
const db = mongoose.connection;
const mongoDBURL = 'mongodb://localhost:27017/auto';
const cookieParser = require('cookie-parser');
const app=express();
app.use(parser.json());
app.use(parser.urlencoded({extended: true}));
app.use(cookieParser());
//Creates a schema for user and items
var Schema = mongoose.Schema;

//UserSchama - for users
var UserSchema = new Schema({
	username: String,
	password: String,
	image: String,
	groups: [],
	friends: [],
	interests: [],
	posts: []
});

var User = mongoose.model('User',UserSchema);

//GroupSchema - for groups
var GroupSchema = new Schema({
	title: String,
	members: [],
	posts: [],
	image:String
});
var Group = mongoose.model('Group',GroupSchema);

//PostSchema - for Posts
var PostSchema = new Schema({
	username: String,
	content: String,
	group: String,
	likes: Number,
	link: String
});
var Post = mongoose.model('Post',PostSchema);

//Use express
app.use(express.static('public_html'));
//Connects MongoDB
mongoose.connect(mongoDBURL, {useNewUrlParser : true});
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

/*
Checks if user is already logged in and not timed out			
*/
function authenticate(req, res, next) {
  console.log(req.cookies);
  console.log(sessionKeys);
  if (Object.keys(req.cookies).length > 0) {
    let u = req.cookies.login.username;
    let key = req.cookies.login.key;
    if ( Object.keys(sessionKeys[u]).length > 0 && sessionKeys[u][0] == key) {
      next();
    } else {
      res.send('NOT ALLOWED');
    }
  } else {
    res.send('NOT ALLOWED');
  }
}

/*
Prints out every time the server starts running
*/
const port=80;
app.listen(port, () => 
  console.log(`App listening at http://localhost:${port}`));

  
  
  
 //USER VARIABLES			-
var loggedInUser=' '; 
  
  
//POST------------------------------------------------------------  


 /*
 Adds a new User to the schema of Users				
 It does so by creating a user from the passed in parameters throguh req.
 It then checks if there exists a user with the same name, if there is no user by the same name, it saves the user.
 */
app.post('/add/user/',(req,res) =>{
	let newUser=JSON.parse(req.body.params);
	var user = new User({username:newUser['username'], password:newUser['password'],image:newUser['image'],listings:[],groups:[],friends:[],interests:[],posts:[]});
	var users= mongoose.model('User',UserSchema);
	var save=true;
	users.find({}).exec(function (error, results){
		for(i in results){
			if(results[i].username===user.username){
				save=false;
			}
		}
	});
	if(save){
		user.save(function(err) { if(err) console.log('an error occurred');});
	}
	
});


 /*
 Adds a new Group to the schema of groups.											
 It does so by reading in the apprpriate information of the group from the parameters.
 It then creates the group from those parameters. It then adds the user that created the group
 to the group, as well as adds the group to the users list of groups.
 
 */
app.post('/add/group/',(req,res) =>{
	let newGroup=JSON.parse(req.body.params);
	var group = new Group({title: newGroup['title'],image: newGroup['image'], members:[],posts:[]});
	var username = newGroup['username'];
	var groups= mongoose.model('Group',GroupSchema);
	var save=true;
	groups.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].title===group.title){
				save=false;
			}
		}
	});
	
	
	if(save){	//Saves user if user does not exist prior
		group.members.push(username);
		group.save(function(err) { if(err) console.log('an error occurred');});
	}
	
	//Save group to user
	var users= mongoose.model('User',UserSchema);
	users.find({}).exec(function (error, results){
		for(i in results){
			if(results[i].username===username){
				results[i].groups.push(group.title);
				results[i].save();
				
			}
		}
	});
	
	
	
	
	
});


 /*
 Adds a new Post to the schema of Posts, as well as the user.	DONE - Not sure what happens if there is no group, 
 It does so by first creating the post from the passed in parameters. It then adds the user to the post.
 After that if there is a group it adds the group to the post. It then saves itself.
 If there is no group, it only posts to the users homepage.
 */
app.post('/add/post/',(req,res) =>{
	let newPost=JSON.parse(req.body.param_str);
	var post = new Post({username:newPost['username'],content:newPost['content'], group: newPost['group'],likes:0,link:newPost['link'] });
	
	var users= mongoose.model('User',UserSchema);
	users.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].username===post.username){
				results[i].posts.push(post._id);
				results[i].save(function(err) { if(err) console.log('an error occurred');});
			}
			
		}
	});
	
	//var notInGroup=true;
	var groups= mongoose.model('Group',GroupSchema);
	groups.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].title===newPost.group){
				
				results[i].posts.push(post._id);
				results[i].save(function(err) { if(err) console.log('an error occurred');});
			}
			
		}
	});
	
	
	post.save(function(err) { if(err) console.log('an error occurred');});
	
	
});


/*																					
	Adds a user to a group. It does so by first 
	retrieving the logged in user, as well as the name of the group.
	It then adds the users name to the groups list of members,then adds the 
	groups name to the users list of groups.
*/
app.post('/add/user/group',(req,res) =>{
	let info=JSON.parse(req.body.param_str);
	var username = info['username'];
	var group = info['group'];
	
	//Saves user to group
	var groups= mongoose.model('Group',GroupSchema);
	groups.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].title===group){
				results[i].members.push(username);
				results[i].save(function(err) { if(err) console.log('an error occurred');});
			}
			
		}
	});
	
	
	//Save group to user
	var users= mongoose.model('User',UserSchema);
	users.find({}).exec(function (error, results){
		for(i in results){
			if(results[i].username===username){
				results[i].groups.push(group);
				results[i].save(function(err) { if(err) console.log('an error occurred');});
				
			}
		}
	});
	
	
});

/*
	Adds friend to the logged in user.
	The logged in users name as well as the name of the friend is passed in
	as a parameter through the req body.
*/
app.post('/add/user/friend',(req,res) =>{
	
	let info=JSON.parse(req.body.param_str);
	var username = info['username'];
	var friend = info['friend'];
	var users= mongoose.model('User',UserSchema);
	
	users.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].username===username){
				
				
				results[i].friends.push(friend);
				results[i].save(function(err) { if(err) console.log('an error occurred');});
			}
			
		}
	});
	
	
});




/*
	Add like to post			
*/
app.post('/add/like/',(req,res) =>{
	let info=JSON.parse(req.body.param_str);
	var postId=info['postId'];
	var posts= mongoose.model('Post',PostSchema);
	
	posts.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i]._id===postId){
				results[i].likes+=1;
				results[i].save(function(err) { if(err) console.log('an error occurred');});
			}
			
		}
	});
	
	
});

//GET ----------------------------------------------------------------------------- 

/*
 Finds and returns all of the users		
*/
app.get('/get/users/',(req,res) =>{
	var users= mongoose.model('User',UserSchema);
	users.find({}).exec(function (error, results){
	res.setHeader('Content-Type', 'text/plain');
	res.send(JSON.stringify(results,null,4));
	});
	
});


/*
 Finds and returns all of the Groups		
*/
app.get('/get/groups/',(req,res) =>{
	var groups= mongoose.model('Group',GroupSchema);
	groups.find({}).exec(function (error, results){
	res.setHeader('Content-Type', 'text/plain');
	res.send(JSON.stringify(results,null,4));
	});
	
});

/*
Finds and returns all of the posts			
*/
app.get('/get/posts/',(req,res) =>{
	var posts= mongoose.model('Post',PostSchema);
	posts.find({}).exec(function (error, results){
	res.setHeader('Content-Type', 'text/plain');
	res.send(JSON.stringify(results,null,4));
	});
	
});

/*
 Returns all the Post id's for a group as a json array.		
 The name of the gorup is passed in through the query.
 */
app.get('/get/group/posts',(req,res) =>{
	let info=JSON.parse(req.query.param_str);
	var group = info['group'];
	var groups= mongoose.model('Group',GroupSchema);
	var returnVal;
	
	groups.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].title===group){
				returnVal = results[i].posts;
			}
		}
		res.setHeader('Content-Type', 'text/plain');
		res.send(JSON.stringify(returnVal,null,4));
	});

	
});

/*
Returns a JSON array containing every friend name of the passed in user.	
Users name is passed in through the query.
*/
app.get('/get/friends/',(req,res) =>{
	
	var currUser = JSON.parse(req.query.param_str);
	var username = currUser['username'];
	var returnVal;
	var users= mongoose.model('User',UserSchema);
	users.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].username===username){
				returnVal=results[i].friends;
			}
			
		}
		res.setHeader('Content-Type', 'text/plain');
		res.send(JSON.stringify(returnVal,null,4));
	});
	
});


/*
Returns a JSON array containing every friend name of the passed in user.	
Users name is passed in through the query.
*/
app.get('/get/friends/posts',(req,res) =>{
	
	var currUser = JSON.parse(req.query.param_str);
	var username = currUser['username'];
	var returnVal=[];
	var friendsList;
	var users= mongoose.model('User',UserSchema);
	users.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].username===username){
				friendsList=results[i].friends;
			}
			
		}
	});
	
	var posts= mongoose.model('Post',PostSchema);
	posts.find({}).exec(function (error, results){
		for(i in results){
			
			for(j in friendsList){
				
				if(results[i].username===friendsList[j]){
					let param = {username: results[i].username, content: results[i].content ,group:results[i].group, likes: results[i].likes, link:results[i].link};
					let param_str = JSON.stringify(param);
					let params= 'param='+param_str;
					returnVal.push(results[i]._id);
				}
			}
			
		}
		res.setHeader('Content-Type', 'text/plain');
		res.send(returnVal);
	});
	
});

/*
Checks if the user currently is logged in, if not send success and log the user in.			
The name of user as well as the password of the user is passed in through the query.
*/
app.get('/index/',(req,res) =>{
	var foundUser;
	var currUser = JSON.parse(req.query.params);
	var username=currUser['username'];
	var userpass=currUser['password'];
	var users= mongoose.model('User',UserSchema);
	users.find({}).exec(function (error, results){
		
		for(i in results){
			if(results[i].username===username && results[i].password===userpass){
				foundUser=results[i];
				//Adds a cookie
				loggedInUser=username;
				console.log(loggedInUser);
				res.cookie(username, 'value', {maxAge: 360000});
				res.setHeader('Content-Type', 'text/plain');
				res.send("success");
			}
		}
	});
	
});


/*
 Gets all the members of a certain group, groups name passed in through jquery.			
*/
app.get('/get/group/members/',(req,res) =>{
	console.log(req);
	let info=JSON.parse(req.query.param_str);
	var group = info['group'];
	var groups= mongoose.model('Group',GroupSchema);
	var returnVal;
	groups.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].title===group){
				returnVal=results[i].members;
			}
			
		}
	res.setHeader('Content-Type', 'text/plain');
	res.send(JSON.stringify(returnVal,null,4));
	});
	
	
});

/*
Retrieves all of the groups that that the logged in user is part of. Each is returned as a string.		
*/
app.get('/get/user/groups',(req,res) =>{
	let info=JSON.parse(req.query.param_str);
	var username= info['username'];
	var users= mongoose.model('User',UserSchema);
	var returnVal;
	users.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i].username===username){
				returnVal=results[i].groups;
			}
			
		}
	res.setHeader('Content-Type', 'text/plain');
	res.send(JSON.stringify(returnVal,null,4));
	});
	
});

/*
Returns the logged in users image
*/
app.get('/get/image/',(req,res) =>{

    let info=JSON.parse(req.query.params);
    var username= info['username'];
    var users= mongoose.model('User',UserSchema);
    var returnVal;
    users.find({}).exec(function (error, results){
        for(i in results){
            if(results[i].username===username){

                returnVal=results[i].image;
            }
        }
    console.log(returnVal);
    res.setHeader('Content-Type', 'text/plain');
    res.send(JSON.stringify(returnVal,null,4));
    });

});

/*
 Finds and returns all of the Groups names
*/
app.get('/get/groups/names',(req,res) =>{

    var groups= mongoose.model('Group',GroupSchema);
    var returnVal=[];
    groups.find({}).exec(function (error, results){
        for(i in results){
            returnVal.push(results[i].title);

        }
    res.setHeader('Content-Type', 'text/plain');
    res.send(JSON.stringify(returnVal,null,4));
    });

});

/*
Finds and returns all of the Users names
*/
app.get('/get/users/names',(req,res) =>{

    var users= mongoose.model('User',UserSchema);
    var returnVal=[];
    users.find({}).exec(function (error, results){
        for(i in results){

            returnVal.push(results[i].username);

        }
    res.setHeader('Content-Type', 'text/plain');
    res.send(JSON.stringify(returnVal,null,4));
    });

});

/*
Gets and returns all of the id's of the posts made by a certain user in the form of an array, 		
whose name is given in the input query.
*/
app.get('/get/user/posts',(req,res) =>{
	
	let info=JSON.parse(req.query.param_str);
	var username= info['username'];
	var users= mongoose.model('User',UserSchema);
	var returnVal;
	users.find({}).exec(function (error, results){
		for(i in results){
			if(results[i].username===username){
				
				returnVal+=results[i].posts;
			}
		}
	res.setHeader('Content-Type', 'text/plain');
	res.send(JSON.stringify(returnVal,null,4));
	});
	
});


/*
Returns the content of the post given the posts id.
The id of the post is passed in through the query.
@return myReturnString
*/
app.get('/get/postId/',(req,res) =>{
	
	let info=JSON.parse(req.query.param_str);
	var postId = info['postId'];
	var posts= mongoose.model('Post',PostSchema);
	posts.find({}).exec(function (error, results){
		for(i in results){
			
			if(results[i]._id.toString()===postId.toString()){
				let param = {username: results[i].username, content: results[i].content ,group:results[i].group, likes: results[i].likes, link:results[i].link};
				let param_str = JSON.stringify(param);
				let params= 'param='+param_str;
				res.setHeader('Content-Type', 'text/plain');
				res.send(param_str);
			}
			
		}
	});
	
});


/*
Returns the content of the post given the posts id.
The id of the post is passed in through the query.
@return myReturnString
*/
app.get('/get/loggedInUser/',(req,res) =>{
	
	res.setHeader('Content-Type', 'text/plain');
	res.send(loggedInUser);
	
});



//Set fs to require
const fs = require('fs');

