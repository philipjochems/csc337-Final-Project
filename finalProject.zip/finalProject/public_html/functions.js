/*
Name: Michael Featherston and Philip Jochems
Class: CSC337
Assignment: Final Project
File: functions.js
Purpose: This file contains all of the functions that retrieve the data from the html and uses that data to call the functions and retrieve/send data to the server.
Some of these calls are adding user, group, posts, as well as adding friends to users, add a user to a group, retrieve the logged in user, retrieve a message, 
retrieve user image, and much more. Each of these functions are made to communicate with the server.js, and display the information retrieved/sent on the html pages.


*/


var currentUser='';

/*
Login for the user, checks if user is logged in already, if not then log in to the server, otherwise does not.

*/
function login(){	
    let u = $('#loginusername').val();
    let p = $('#loginpassword').val();
	let param = {username: u, password: p};
    let param_str = JSON.stringify(param);
	let params= 'param='+param_str;

    $.ajax({
        url: '/index/',
		data: {params: param_str},
        method: 'GET',
        success: function(result){
            if (result == "success"){
                window.location.href = "/home.html";
                currentUser=u;
                getFriendPosts();
            }else{
                $('#errorMsg').text(result);
            }
        }
    });
}

/*
Adds a user to the schema of users on the server.
*/
function addUser(){	
    let u = $('#newusername').val();
    let p = $('#newpassword').val();
	let pic =  $('#profilePic').val();
    let param = {username: u, password: p, image:pic};
    let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/add/user/',
        data: {params: param_str},
        method: 'POST',
        success: function(result){
            alert('user added');
        }
    });
}

/*
Adds a group to the schema of users on the server.
*/
function addGroup(){		
	let u = currentUser;
    let g = $('#groupName').val();
    let i = $('#groupPic').val();
    let params = {title: g, image: i, username: u};
    let paramStr = JSON.stringify(params);
    $.ajax({
        url: '/add/group/',
        data: {params: paramStr},
        method: 'POST',
        success: function(result){
            
        }
    });
	alert('Group Created');
	window.location.href = "/home.html";
}


/*
Purpose: this function is used to request an item add to the mongoDB server
created in server.js. It takes the input title, description, image, price, and 
status and passes these as the parameters, (all in stringified JSON format) to 
the server via jquery AJAX.
*/
function addFriend(){		
    let u = currentUser;
    let n = $('#user2').val(); 
    let param = {username: u, friend: n};
    let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/add/user/friend/',
        data:  {params, param_str},
        method: 'POST',
        success: function(result){
            document.getElementById("friend").innerHTML = result;
			alert("friend Added");
        }
    });
	getFriendPosts();
	alert('Friend Created');
	window.location.href = "/home.html";
}

/*
Returns the friends of a the logged in user.
*/
function getFriendList(){		
	let u = currentUser;
	let param = {username: u};
	let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/get/friends/',
		data:  {params, param_str},
        method: 'GET',
		
        success: function(result){	//Returns a json string with the names of the friends - fix parsing as right now item= index number for result
            let listObject = JSON.parse(result);
            var updateHTML = "";
            for (friend in listObject){
                updateHTML += "<img src='"+listObject[friend].image+".png' alt='profile picture' id ='friendImage'><span class='friendName'> -"+ listObject[friend].username + "</span><br/><br/>";   
            }
            document.getElementById("scrollBodyF").innerHTML = updateHTML;
        }
    });
}



/*
Returns the names of the groups that the user is in;
*/
/*
Returns the names of the groups that the user is in;
*/
function getGroupList(){
    let u = currentUser;
    let param = {username: u};
    let param_str = JSON.stringify(param);
    let params= 'param='+param_str;
    $.ajax({
        url: '/get/user/groups',
        data:  {params, param_str},
        method: 'GET',
        success: function(result){            //Returns a json string with the names of the users groups - fix parsing as right now item= index number for result
            let listObject = JSON.parse(result);
            var updateHTML = "";
            for (group in listObject){
                var currentGroup = listObject[group];
                updateHTML += "<button onclick='getGroupPosts(\""+currentGroup+"\");'>"+ currentGroup + "</button><br/><br/>";

            }
            document.getElementById("scrollBodyG").innerHTML = updateHTML;
        }
    });
}

/*
Returns the id's for the posts for the passed in group, then
it finds their values using getPostFromId and displays it on the html page.
*/
function getGroupPosts(currentGroup){

    let g = currentGroup;            
    let param = {group: g};
    let param_str = JSON.stringify(param);
    let params= 'param='+param_str;

    $.ajax({
        url: '/get/group/posts',
        data:  {params, param_str},
        method: 'GET',
        success: function(result){                    
            let listObject = JSON.parse(result);
            var updateHTML = "";
            for (i in listObject){
                var currentPost=getPostFromId(listObject[i]);
                if(currentPost!=null){
                    updateHTML += "<div class ='post'><div id='user'>"+currentPost.username+" in "+currentPost.group+"</div><br><p id ='message'>"+currentPost.content+"</p><br><div id='link'><a href ='"+currentPost.link+"'></a></div><br><br></div>";
                }
            }
            document.getElementById("scrollBodyP").innerHTML = updateHTML;
        }
    });

}

/*
 Finds and retrieves all of the post's id's for the logged in user. 
*/

function getUserPosts(){
	let u = currentUser;
	let param = {username: u};
	let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/get/user/posts',
		data:  {params, param_str},
        method: 'GET',
        success: function(result){
            
            let listObject = JSON.parse(result);
            var updateHTML = "";
            for (item in listObject){
                console.log(listObject[item]);
                updateHTML += "<div class ='post'><div id='user'>"+listObject[item].username+"</div><br><p id ='message'>"+listObject[item].content+"</p><br><div id='link'><a href ='"+listObject[post].link+"'></a></div><br><br></div>";   
            }
			
            document.getElementById("scrollBody").innerHTML = updateHTML;
            window.location.reload();
        }
    });
}



/*
Returns the members of a group, whose name is given as a param
*/
function getMemberList(){		
	let g = $('#newusername').val();				
	let param = {group: g};
	let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/get/group/members/',
		data:  {params, param_str},
        method: 'GET',
        success: function(result){
            let listObject = JSON.parse(result);
            var updateHTML = "";
            for (item in listObject){
                updateHTML += item + "<br/><br/>";   
            }
			
            document.getElementById("scrollBody").innerHTML = updateHTML;
        }
    });
}


/*
Creates a post that the user than posts to a given group
*/
function addPost(){				
    let u = currentUser;
	console.log(u);
    let m = $('#postContent').val();
    let g = $('#postGroup').val(); 
	let l = $('#postLink').val();
    var d = new Date();
    var t = d.getTime();
    let param = {username: u, content: m ,group:g, time: t,link:l};
	let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/add/post/',
        data:  {params, param_str},
        method: 'POST',
        success: function(result){
            document.getElementById("friend").innerHTML = result;
			alert("POST ADDED");
			window.location.href = "/home.html";
			
        }
    });
}

/*
Adds the user as a member to a group, whose name is given as an input
on joinGroup.html
*/
function addMember(){			
    let u = currentUser;
    let g = $('#joinGroup').val();
    let param = {username:u , group:g};
	let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/add/user/group',
        data:  {params, param_str},
        method: 'POST',
        success: function(result){
            document.getElementById("friend").innerHTML = result;
			
        }
    });
	alert('Joined Group');
	window.location.href = "/home.html";
}

/*
Adds a like to a given post

*/	
function addLike(){		
    let u = currentUser;
    let params = {user: u, type: t, title: n};
    let paramStr = JSON.stringify(params);
    $.ajax({
        url: '/add/Member/',
        data:  {params, paramStr},
        method: 'POST',
        success: function(result){
            document.getElementById("friend").innerHTML = result;
        }
    });
}

/*
Makes sure that the user is logged in, as well as that information on the pages gets updated.
*/
setInterval(function(){
	
	if(!window.location.href.includes("/index.html")){
		$.ajax({
        url: '/get/loggedInUser/',
        method: 'GET',
        success: function(result){
            currentUser=result;
        }
    });
	if(currentUser ===' ' || currentUser==null){		// if not logged in - kick out user 
		window.location.href = "/index.html";
		
	}else if(window.location.href.includes("/home.html")){
		if(document.getElementById("scrollBody").innerHTML ==''){
            getFriendPosts();
			if(document.getElementById("scrollBody").innerHTML !=''){
				getImage();
			}
            
            
		}
	}else if(window.location.href.includes("/group.html")){	//Group page
        getGroupList();
        //getImage();
    }else if(window.location.href.includes("/addGroup.html")){ //Add Group page
        getGroups();
    }
    else if(window.location.href.includes("/addFriend.html")){ //Add Friend page
        getUsers();
	}else if(window.location.href.includes("/joinGroup.html")){ // Join Group page
        getGroups();
    }
		
	}
	
	
}, 2000);




/*
Returns all of the logged in users friends posts abd displays them on the homepage
*/
function getFriendPosts(){
    let u = currentUser;
	let param = {username: u};
	let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
    $.ajax({
        url: '/get/friends/posts',
		data:  {params, param_str},
        method: 'GET',
        success: function(result){	//Returns a json string with the names of the friends - fix parsing as right now item= index number for result
            let listObject = JSON.parse(result);
            var updateHTML = '';
			
			for (i in listObject){
				
				
				var currentPost=getPostFromId(listObject[i]);
				
				if(currentPost!=null){
                    if(currentPost.group == ''){
                        updateHTML+="<div class ='post'><div id = 'user'>"+currentPost.username+"</div><br><p id ='message'>"+currentPost.content+"</p><br><div id='link'><a href ='"+currentPost.link+"'>link</a></div><br><br></div>";
                    }else{
                        updateHTML += "<div class ='post'><div id = 'user'>"+currentPost.username+" in "+currentPost.group+"</div><br><p id ='message'>"+currentPost.content+"</p><br><div id='link'><a href ='"+currentPost.link+"'></a></div><br><br></div>";
                        }
                
				}
			}			
            document.getElementById("scrollBody").innerHTML = updateHTML;
        }    
    });
}

/*

Returns the image of the logged in user

*/
function getImage(){
    let u = currentUser;
    let param = {username: u};
    let param_str = JSON.stringify(param);
    $.ajax({
        url: '/get/image/',
        data: {params: param_str},
        method: 'GET',
        success: function(result){
            document.getElementById("profPic").src = result;
            
        }
    });

}

/*
Retrieves all of the names of all of the groups and displays them on the add Group page.

*/
function getGroups(){
    $.ajax({
        url: '/get/groups/names',
        method: 'GET',
        success: function(result){
            var itemObject = JSON.parse(result);
            var updateHTML = "<h3>Current Groups</h3>";
            for(group in itemObject){
                updateHTML += itemObject[group] +"<br><br>";
            }
            document.getElementById("groupList").innerHTML = updateHTML;
        }
    });
}

/*
Retrieves all of the names of all of the users and displays them on the add friend page.

*/
function getUsers(){
    $.ajax({
        url: '/get/groups/names',
        method: 'GET',
        success: function(result){
            var itemObject = JSON.parse(result);
            var updateHTML = "<h3>Current Users</h3>";
            for(user in itemObject){
                updateHTML += itemObject[user] +"<br><br>";
            }
            document.getElementById("userList").innerHTML = updateHTML;
        }
    });
}

/*
Returns the content of a post given its id.
*/
function getPostFromId(id){
    
	let param = {postId: id};
	let param_str = JSON.stringify(param);
	let params= 'param='+param_str;
	var curr='';
    $.ajax({
        url: '/get/postId',
		data:  {params, param_str},
		async: false,  
        method: 'GET',
        success: function(result){	//Returns a json string with the names of the friends - fix parsing as right now item= index number for result
		let listObject = JSON.parse(result);
         currentPost=listObject;
		 curr=listObject;
		 
        }
    });
	return curr
}
